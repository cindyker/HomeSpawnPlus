/**
 * 
 */
package org.morganm.homespawnplus.server.bukkit;

import org.bukkit.block.BlockFace;

/**
 * @author morganm
 *
 */
public enum BukkitBlockFace {
    NORTH(BlockFace.NORTH),
    EAST(BlockFace.EAST),
    SOUTH(BlockFace.SOUTH),
    WEST(BlockFace.WEST),
    UP(BlockFace.UP),
    DOWN(BlockFace.DOWN);
    
    private BlockFace face;
    private BukkitBlockFace(BlockFace face) {
        this.face = face;
    }
    
    public BlockFace getBlockFace() {
        return face;
    }
    
    /** Given an API BlockFace, return the corresponding Bukkit BlockFace.
     * 
     * @param blockFace
     * @return
     */
    public BlockFace getBlockFace(org.morganm.homespawnplus.server.api.BlockFace blockFace) {
        switch(blockFace) {
        NORTH:
            return this.NORTH.getBlockFace();
        }
    }
}
