/**
 * 
 */
package org.morganm.homespawnplus.server.bukkit;

import org.morganm.homespawnplus.server.api.Block;
import org.morganm.homespawnplus.server.api.BlockFace;

/**
 * @author morganm
 *
 */
public class BukkitBlock implements Block {
    private final org.bukkit.block.Block bukkitBlock;
    
    public BukkitBlock(org.bukkit.block.Block bukkitBlock) {
        this.bukkitBlock = bukkitBlock;
    }
    
    /* (non-Javadoc)
     * @see org.morganm.homespawnplus.server.api.Block#isBed()
     */
    @Override
    public boolean isBed() {
        // TODO Auto-generated method stub
        return false;
    }

}
