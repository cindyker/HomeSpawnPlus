/**
 * 
 */
package org.morganm.homespawnplus.server.api;


/** API for handling Block objects.
 * 
 * @author morganm
 *
 */
public interface Block {
    /**
     * Gets the block at the given face
     *
     * @param face Face of this block to return
     * @return Block at the given face
     * @see #getRelative(BlockFace, int)
     */
    public Block getRelative(BlockFace face);

    /**
     * Checks if this block represents a bed.
     * 
     * @return true if the block is a bed
     */
    public boolean isBed();
}
